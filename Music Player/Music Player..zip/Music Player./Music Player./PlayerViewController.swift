//
//  PlayerViewController.swift
//  Music Player
//
//  Created by Anshul Kumaria on 23/10/25.
//

import UIKit
import AVFoundation

class PlayerViewController: UIViewController {
    
    // MARK: - Public vars
    public var position: Int = 0
    public var songs: [ViewController.Song] = []
    
    // MARK: - Outlets
    @IBOutlet var holder: UIView!
    
    // MARK: - Player
    var player: AVAudioPlayer?
    
    // MARK: - UI Elements
    private lazy var albumImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 12
        return imageView
    }()
    
    private lazy var songNameLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 0
        label.font = UIFont.boldSystemFont(ofSize: 22)
        return label
    }()
    
    private lazy var artistNameLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 1
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = .secondaryLabel
        return label
    }()
    
    private lazy var albumNameLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 1
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = .secondaryLabel
        return label
    }()
    
    // MARK: - Control Buttons
    private let playPauseButton = UIButton(type: .system)
    private let nextButton = UIButton(type: .system)
    private let previousButton = UIButton(type: .system)
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if holder.subviews.isEmpty {
            configure()
        }
    }
    
    // MARK: - Setup UI & Player
    func configure() {
        let song = songs[position]
        
        guard let path = Bundle.main.path(forResource: song.track, ofType: "mp3") else {
            print("⚠️ Audio file not found: \(song.track).mp3")
            return
        }
        
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default)
            try session.setActive(true, options: .notifyOthersOnDeactivation)
            
            let fileURL = URL(fileURLWithPath: path)
            player = try AVAudioPlayer(contentsOf: fileURL)
            player?.prepareToPlay()
            player?.volume = 0.5
            player?.play()
            print("✅ Now playing: \(song.track)")
        } catch {
            print("❌ Audio setup/playback error: \(error)")
        }
        
        // MARK: - Layout
        albumImageView.frame = CGRect(
            x: 20,
            y: 20,
            width: holder.frame.width - 40,
            height: holder.frame.width - 40
        )
        albumImageView.image = UIImage(named: song.image)
        holder.addSubview(albumImageView)
        
        songNameLabel.frame = CGRect(
            x: 20,
            y: albumImageView.frame.maxY + 10,
            width: holder.frame.width - 40,
            height: 40
        )
        songNameLabel.text = song.name
        holder.addSubview(songNameLabel)
        
        albumNameLabel.frame = CGRect(
            x: 20,
            y: songNameLabel.frame.maxY + 5,
            width: holder.frame.width - 40,
            height: 30
        )
        albumNameLabel.text = song.album
        holder.addSubview(albumNameLabel)
        
        artistNameLabel.frame = CGRect(
            x: 20,
            y: albumNameLabel.frame.maxY + 5,
            width: holder.frame.width - 40,
            height: 30
        )
        artistNameLabel.text = song.artist
        holder.addSubview(artistNameLabel)
        
        // MARK: - Buttons Setup
        let buttonSize: CGFloat = 70
        let yPosition = artistNameLabel.frame.maxY + 40
        
        previousButton.frame = CGRect(
            x: holder.frame.width / 2 - buttonSize - 60,
            y: yPosition,
            width: buttonSize,
            height: buttonSize
        )
        playPauseButton.frame = CGRect(
            x: (holder.frame.width - buttonSize) / 2,
            y: yPosition,
            width: buttonSize,
            height: buttonSize
        )
        nextButton.frame = CGRect(
            x: holder.frame.width / 2 + 60,
            y: yPosition,
            width: buttonSize,
            height: buttonSize
        )
        
        previousButton.setImage(UIImage(systemName: "backward.fill"), for: .normal)
        playPauseButton.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
        nextButton.setImage(UIImage(systemName: "forward.fill"), for: .normal)
        
        previousButton.tintColor = .systemBlue
        playPauseButton.tintColor = .systemBlue
        nextButton.tintColor = .systemBlue
        
        previousButton.addTarget(self, action: #selector(didTapPreviousButton), for: .touchUpInside)
        playPauseButton.addTarget(self, action: #selector(didTapPlayPauseButton), for: .touchUpInside)
        nextButton.addTarget(self, action: #selector(didTapNextButton), for: .touchUpInside)
        
        holder.addSubview(previousButton)
        holder.addSubview(playPauseButton)
        holder.addSubview(nextButton)
        
        // MARK: - Volume Slider
        let slider = UISlider(frame: CGRect(
            x: 30,
            y: holder.frame.height - 80,
            width: holder.frame.width - 60,
            height: 40
        ))
        slider.value = 0.5
        slider.addTarget(self, action: #selector(didSlideSlider(_:)), for: .valueChanged)
        holder.addSubview(slider)
    }
    
    // MARK: - Controls
    @objc func didTapPreviousButton() {
        if position > 0 {
            position -= 1
            reloadSong()
        }
    }
    
    @objc func didTapNextButton() {
        if position < songs.count - 1 {
            position += 1
            reloadSong()
        }
    }
    
    @objc func didTapPlayPauseButton() {
        guard let player = player else { return }
        if player.isPlaying {
            player.pause()
            playPauseButton.setImage(UIImage(systemName: "play.circle.fill"), for: .normal)
            UIView.animate(withDuration: 0.2) {
                self.albumImageView.frame = CGRect(
                    x: 30,
                    y: 30,
                    width: self.holder.frame.width - 60,
                    height: self.holder.frame.width - 60
                )
            }
        } else {
            player.play()
            playPauseButton.setImage(UIImage(systemName: "pause.circle.fill"), for: .normal)
            
            UIView.animate(withDuration: 0.2) {
                self.albumImageView.frame = CGRect(
                    x: 10,
                    y: 10,
                    width: self.holder.frame.width - 20,
                    height: self.holder.frame.width - 20
                )
            }
        }
    }
    
    private func reloadSong() {
        player?.stop()
        for subview in holder.subviews {
            subview.removeFromSuperview()
        }
        configure()
    }
    
    // MARK: - Volume Control
    @objc func didSlideSlider(_ slider: UISlider) {
        player?.volume = slider.value
    }

    // MARK: - Cleanup
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        player?.stop()
    }
}

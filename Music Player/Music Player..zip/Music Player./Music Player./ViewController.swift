import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet var table: UITableView!

    var songs = [Song]()

    override func viewDidLoad() {
        super.viewDidLoad()
        configureSongs()
        table.delegate = self
        table.dataSource = self

        // If you didn't set the cell style in storyboard, you can register here:
        // table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }

    // MARK: - UITableViewDataSource

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return songs.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        // Make sure your prototype cell in storyboard has Identifier = "cell" and Style = Subtitle
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        let song = songs[indexPath.row]
        cell.textLabel?.text = song.name
        cell.detailTextLabel?.text = song.album
        cell.accessoryType = .disclosureIndicator

        if let image = UIImage(named: song.image) {
            // Resize nicely for table cell thumbnail
            let thumbnail = image.preparingThumbnail(of: CGSize(width: 60, height: 60))
            cell.imageView?.image = thumbnail
            cell.imageView?.layer.cornerRadius = 6
            cell.imageView?.clipsToBounds = true
        } else {
            cell.imageView?.image = nil
        }

        cell.textLabel?.font = UIFont(name: "Helvetica-Bold", size: 18)
        cell.detailTextLabel?.font = UIFont(name: "Helvetica", size: 15)

        return cell
    }

    // MARK: - UITableViewDelegate

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

        let position = indexPath.row

        // instantiate by storyboard ID — ensure storyboard ID 'player' is set on the Player VC in IB
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "player") as? PlayerViewController else {
            // if this fails, storyboard id or custom class wasn't set correctly
            print("Failed to instantiate PlayerViewController with identifier 'player'")
            return
        }

        vc.songs = songs
        vc.position = position
        present(vc, animated: true)
    }

    // MARK: - Data

    func configureSongs() {
        // Use asset names that actually exist in Assets.xcassets
        songs.append(Song(name: "Glorious Purpose",
                          album: "Loki Season 1",
                          artist: "Natalie Holt",
                          image: "Cover - 3.",
                          track: "Glorious Purpose."))
        songs.append(Song(name: "Catch Up",
                          album: "Loki Season 2",
                          artist: "Natalie Holt",
                          image: "Cover - 1.",
                          track: "Catch Up."))
        songs.append(Song(name: "Fiction Problem",
                          album: "Loki Season 2",
                          artist: "Natalie Holt",
                          image: "Cover - 2.",
                          track: "Fiction Problem."))
    }

    // MARK: - Song model

    struct Song {
        let name: String
        let album: String
        let artist: String
        let image: String   // name in assets
        let track: String   // filename or resource id for the audio
    }
}
